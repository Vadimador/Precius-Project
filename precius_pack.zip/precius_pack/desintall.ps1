echo "======================================"
echo "Arret du Service Precius"
echo "======================================"
Stop-Service -Name Precius

echo "======================================"
echo "Désinstallation du Service"
echo "======================================"

C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u .\Precius-service.exe

echo "done !"