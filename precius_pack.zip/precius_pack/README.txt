Precius service :
	install : C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe .\Precius-service.exe
	unninstall : C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u .\Precius-service.exe

	Go to Services et start Precius service.
	Or exec on powershell : Start-Service -name Precius
	You can see his log with Event Observer precius-log

To configure modules (if it does not exist, start Precius service to create it) : 
	C:\Program Files\Precius\modules.conf
To configure sectors (same)
	C:\Program Files\Precius\sectors.conf


Precius Talker :
	don't move it from his file.
	Utilise it as a normal .exe