echo "======================================"
echo "Installation du Service"
echo "======================================"

C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe .\Precius-service.exe

echo "======================================"
echo "Démarrage du Service Precius"
echo "======================================"
Start-Service -Name Precius

echo "Pour configurer Précius veuillez voir les fichiers suivant dans C:\Program File\Precius"
echo "      - modules.conf"
echo "      - sectors.conf"